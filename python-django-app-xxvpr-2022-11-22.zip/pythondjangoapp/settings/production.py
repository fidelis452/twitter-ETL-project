from pythondjangoapp.settings.base import *

DEBUG = False

INSTALLED_APPS += (
                   # other apps for production
                   )
